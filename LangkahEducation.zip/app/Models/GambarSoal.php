<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GambarSoal extends Model
{
    protected $table = 'gambar_soal';
    protected $guarded = [];
}
